var biliScopeOptions = null;
var noteData = null;
var tagColors = null;
var enableTagColor = null;
var userProfileCard = null;
var videoProfileCard = null;
